Preparation before installation:
  1. UpdateService: UpdateService downloads the service fabric runtime packages from the internet, and exposes an http/ https endpoint for the cluster nodes to download
	 Prepare endpointBaseAddress of the ServiceFabricUpdateService.exe.config if it's https:
         a. Install the certificate of the issuer of the ServiceFabricUpdateService server certificate on every service fabric cluster node under LocalMachine\TrustedRoot
         b. Install both the issuer certificate and the ServiceFabricUpdateService server certificate on the ServiceFabricUpdateService server under LocalMachine

     Prepare the service fabric cluster:
	     a. Turn on fabricClusterAutoupgradeEnabled on the cluster json config
		 b. Configure the ServiceFabricUpdateService endpoint as on the cluster config in the format of '<endpointBaseAddress>/api/files/goalstate'.
		     Example: Assume your endpointBaseAddress is configured as https://myServer:443 on the ServiceFabricUpdateService.exe.config, then configure https://myServer:443/api/files/goalstate on the cluster json config:
                       "fabricSettings": [
                       {
                           "name": "UpgradeOrchestrationService",
                           "parameters": [
                           {
                               "name": "GoalStateFileUrl",
                               "value": "https://myServer:443/api/files/goalstate"
                           }]
                       }
                       ] 
		 c. Create the cluster, or perform config upgrade for the existing cluster.

  2. TelemetryService: on the cluster json config, if enableTelemetry is turned on and if 'diagnosticsStore' is a file share, TelemetryService uploads telemetry data under the diagnostics store.
     Prepare diagnosticsStoreConnectionString of the ServiceFabricUpdateService.exe.config: ServiceFabricUpdateService service runs under System account. So, make sure proper read/ list permissions of this file share are granted to the ServiceFabricUpdateService server.


Install:
Deploy.ps1 -install


Uninstall:
Deploy.ps1 -uninstall


Config upgrade:
Update ServiceFabricUpdateService.exe.config, and restart the windows service ServiceFabricUpdateService


Code upgrade:
Step 1: Uninstall the service by invoking 'Deploy.ps1 -uninstall'
Step 2: Download the target code package, and replace the ServiceFabricUpdateService.exe.config under this folder
Step 3: Install the new service binaries by invoking 'Deploy.ps1 -install'


Logs:
The service logs are in the 'Log' folder right beside ServiceFabricUpdateService.exe.